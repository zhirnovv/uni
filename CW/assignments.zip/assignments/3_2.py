a = 20
b = 5999

print(a ** b)
